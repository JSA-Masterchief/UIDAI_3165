import 'package:flutter/material.dart';
import '../content_loader.dart';
import '../language_provider.dart';

class CentersScreen extends StatefulWidget {
  const CentersScreen({super.key});

  @override
  State<CentersScreen> createState() => _CentersScreenState();
}

class _CentersScreenState extends State<CentersScreen> {
  String searchQuery = '';

  @override
  Widget build(BuildContext context) {
    final lang = LanguageProvider.currentLang;

    return FutureBuilder<Map<String, dynamic>>(
      future: ContentLoader.loadContent(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final List states = snapshot.data!['centers'];

        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Search Bar
            TextField(
              decoration: InputDecoration(
                hintText: lang == 'en'
                    ? 'Search district or PIN'
                    : 'जिला या पिन खोजें',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
              onChanged: (value) {
                setState(() {
                  searchQuery = value.toLowerCase();
                });
              },
            ),
            const SizedBox(height: 16),

            ...states.map((state) {
              final stateName = state['state'][lang];

              final districts = (state['districts'] as List)
                  .where((d) =>
                      d['name'][lang]
                          .toLowerCase()
                          .contains(searchQuery) ||
                      (d['locations'] as List).any((l) =>
                          l[lang].toLowerCase().contains(searchQuery)))
                  .toList();

              if (districts.isEmpty) return const SizedBox();

              return Card(
                elevation: 3,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                margin: const EdgeInsets.only(bottom: 12),
                child: ExpansionTile(
                  leading: const Icon(Icons.map, color: Color(0xFFD32F2F)),
                  title: Text(
                    stateName,
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                  children: districts.map<Widget>((district) {
                    return ExpansionTile(
                      title: Text(district['name'][lang]),
                      children: (district['locations'] as List)
                          .map<Widget>(
                            (loc) => ListTile(
                              leading: const Icon(Icons.location_on,
                                  color: Color(0xFFD32F2F)),
                              title: Text(loc[lang]),
                            ),
                          )
                          .toList(),
                    );
                  }).toList(),
                ),
              );
            }),
          ],
        );
      },
    );
  }
}
