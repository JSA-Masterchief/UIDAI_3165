import 'package:flutter/material.dart';
import '../language_provider.dart';

class InsightsScreen extends StatelessWidget {
  const InsightsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final lang = LanguageProvider.currentLang;

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Title
          Text(
            lang == 'en' ? 'Insights & Analysis' : 'विश्लेषण और अंतर्दृष्टि',
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),

          // Dashboard_1
          _DashboardCard(
            imagePath: 'assets/images/dashboards/dashboard_1.jpg',
            title: lang == 'en'
                ? 'Low Aadhaar Update States'
                : 'कम आधार अपडेट वाले राज्य',
          ),

          const SizedBox(height: 24),

          // Dashboard_2
          _DashboardCard(
            imagePath: 'assets/images/dashboards/dashboard_2.jpg',
            title: lang == 'en'
                ? 'Age-wise Aadhaar Updates'
                : 'आयु-वार आधार अपडेट',
          ),
          const SizedBox(height: 24),

//Dashboard_3
_DashboardCard(
  imagePath: 'assets/images/dashboards/dashboard_3.jpg',
  title: lang == 'en'
      ? 'District-wise Aadhaar Update Coverage'
      : 'जिला-वार आधार अपडेट कवरेज',
),

        ],
      ),
    );
  }
}

class _DashboardCard extends StatelessWidget {
  final String imagePath;
  final String title;

  const _DashboardCard({
    required this.imagePath,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Text(
              title,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 16,
              ),
            ),
          ),
          ClipRRect(
            borderRadius: const BorderRadius.only(
              bottomLeft: Radius.circular(12),
              bottomRight: Radius.circular(12),
            ),
            child: Image.asset(
              imagePath,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
          ),
        ],
      ),
    );
  }
}
