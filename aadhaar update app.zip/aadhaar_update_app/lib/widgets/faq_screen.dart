import 'package:flutter/material.dart';
import 'package:aadhaar_update_app/content_loader.dart';
import 'package:aadhaar_update_app/language_provider.dart';

class FAQScreen extends StatelessWidget {
  const FAQScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Map<String, dynamic>>(
      future: ContentLoader.loadContent(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final content = snapshot.data!;
        final lang = LanguageProvider.currentLang;
        final faqs = content['faq'][lang] as List<dynamic>;

        return Scaffold(
          appBar: AppBar(title: const Text('FAQs')),
          body: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: faqs.length,
            itemBuilder: (context, index) {
              final faq = faqs[index];
              return Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                elevation: 3,
                child: ExpansionTile(
                  leading: const Icon(Icons.help_outline, color: Color(0xFFD32F2F)),
                  title: Text(faq['question']),
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(12),
                      child: Text(faq['answer']),
                    ),
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }
}
