import 'package:flutter/material.dart';

class LanguageProvider extends ChangeNotifier {
  static String _currentLang = 'en';

  static String get currentLang => _currentLang;

  static void toggle() {
    _currentLang = _currentLang == 'en' ? 'hi' : 'en';
  }

  static void setLanguage(String lang) {
    _currentLang = lang;
  }
}
