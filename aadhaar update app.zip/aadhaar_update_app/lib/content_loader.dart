import 'dart:convert';
import 'package:flutter/services.dart';

class ContentLoader {
  static Map<String, dynamic>? _cache;

  static Future<Map<String, dynamic>> loadContent() async {
    if (_cache != null) return _cache!;

    final jsonString =
        await rootBundle.loadString('assets/data/app_content.json');

    _cache = json.decode(jsonString) as Map<String, dynamic>;
    return _cache!;
  }
}
