import 'package:flutter/material.dart';

import 'content_loader.dart';
import 'language_provider.dart';
import 'how_to_update_screen.dart';
import 'widgets/centers_screen.dart';
import 'widgets/faq_screen.dart';
import 'widgets/insights_screen.dart';

void main() {
  runApp(const AadhaarApp());
}

class AadhaarApp extends StatelessWidget {
  const AadhaarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Aadhaar Update Help',
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFFF5F6FA),
        primaryColor: const Color(0xFFD32F2F),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 1,
        ),
      ),
      home: const DashboardScreen(),
    );
  }
}

// Dashboard
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  Widget _currentContent = const InsightsScreen();

  @override
  Widget build(BuildContext context) {
    final lang = LanguageProvider.currentLang;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Image.asset('assets/images/aadhaar_logo.png', height: 30),
            const SizedBox(width: 10),
            const Text(
              'Aadhaar Update Help',
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
          ],
        ),
        actions: [
          // Language
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Row(
              children: [
                _LangButton(
                  label: 'EN',
                  isActive: lang == 'en',
                  onTap: () {
                    setState(() {
                      LanguageProvider.setLanguage('en');
                    });
                  },
                ),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 4),
                  child: Text('|', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
                _LangButton(
                  label: 'HI',
                  isActive: lang == 'hi',
                  onTap: () {
                    setState(() {
                      LanguageProvider.setLanguage('hi');
                    });
                  },
                ),
              ],
            ),
          ),
        ],
      ),
      body: Row(
        children: [
          // Main Content
          Expanded(
            flex: 4,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: _currentContent,
            ),
          ),

          // Sidebar
          Container(
            width: 240,
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(
              color: Colors.white,
              border: Border(left: BorderSide(color: Colors.black12)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _SideMenuItem(
                  icon: Icons.bar_chart,
                  title: lang == 'en' ? 'Dashboard' : 'डैशबोर्ड',
                  onTap: () => setState(() {
                    _currentContent = const InsightsScreen();
                  }),
                ),
                _SideMenuItem(
                  icon: Icons.edit,
                  title: lang == 'en' ? 'How To Update' : 'अपडेट कैसे करें',
                  onTap: () => setState(() {
                    _currentContent = const HowToUpdateScreen();
                  }),
                ),
                _SideMenuItem(
                  icon: Icons.card_giftcard,
                  title: lang == 'en' ? 'Benefits & Schemes' : 'लाभ और योजनाएँ',
                  onTap: () => setState(() {
                    _currentContent = const BenefitsScreen();
                  }),
                ),
                _SideMenuItem(
                  icon: Icons.location_on,
                  title: lang == 'en' ? 'Centers' : 'केंद्र',
                  onTap: () => setState(() {
                    _currentContent = const CentersScreen();
                  }),
                ),
                _SideMenuItem(
                  icon: Icons.help_outline,
                  title: lang == 'en' ? 'FAQs' : 'सामान्य प्रश्न',
                  onTap: () => setState(() {
                    _currentContent = const FAQScreen();
                  }),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _LangButton extends StatelessWidget {
  final String label;
  final bool isActive;
  final VoidCallback onTap;

  const _LangButton({
    required this.label,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: isActive ? const Color(0xFFD32F2F) : Colors.transparent,
          borderRadius: BorderRadius.circular(4),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: isActive ? Colors.white : Colors.black,
          ),
        ),
      ),
    );
  }
}

class _SideMenuItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  const _SideMenuItem({
    required this.icon,
    required this.title,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Row(
          children: [
            Icon(icon, color: const Color(0xFFD32F2F)),
            const SizedBox(width: 12),
            Text(title, style: const TextStyle(fontWeight: FontWeight.w500)),
          ],
        ),
      ),
    );
  }
}

class BenefitsScreen extends StatelessWidget {
  const BenefitsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Map<String, dynamic>>(
      future: ContentLoader.loadContent(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final content = snapshot.data!;
        final lang = LanguageProvider.currentLang;
        final List benefits = content['benefits']['points'];
        final List schemes = content['schemes']['list'];

        return SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Benefits
              Text(
                content['benefits']['title'][lang],
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),

              ...benefits.map(
                (b) => _UniformCard(
                  icon: Icons.check_circle,
                  text: b[lang],
                ),
              ),

              const SizedBox(height: 24),

              Text(
                content['schemes']['title'][lang],
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),

              ...schemes.map(
                (s) => _UniformCard(
                  icon: Icons.account_balance_wallet,
                  text: s['name'][lang],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _UniformCard extends StatelessWidget {
  final IconData icon;
  final String text;

  const _UniformCard({
    required this.icon,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Icon(icon, color: const Color(0xFFD32F2F)),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                text,
                style: const TextStyle(fontSize: 15),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
