package com.example.aadhaar_update_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
